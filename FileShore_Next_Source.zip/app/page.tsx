'use client';

import { ChangeEvent, DragEvent, FormEvent, useMemo, useRef, useState } from 'react';

type MetadataResult = {
  name: string;
  type: string;
  size: number;
};

type UploadState = 'idle' | 'ready' | 'uploading' | 'success' | 'error';

const formatBytes = (bytes: number) => {
  if (!Number.isFinite(bytes) || bytes < 0) return '—';
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / 1024 ** index;
  return `${value >= 10 || index === 0 ? value.toFixed(0) : value.toFixed(2)} ${units[index]}`;
};

const FileIcon = () => (
  <svg viewBox="0 0 24 24" aria-hidden="true">
    <path d="M7 2h7l5 5v15H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z" />
    <path d="M14 2v6h6" />
    <path d="M9 13h6M9 17h6" />
  </svg>
);

const UploadIcon = () => (
  <svg viewBox="0 0 24 24" aria-hidden="true">
    <path d="M12 16V4" />
    <path d="m7 9 5-5 5 5" />
    <path d="M5 14v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5" />
  </svg>
);

export default function Home() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [state, setState] = useState<UploadState>('idle');
  const [result, setResult] = useState<MetadataResult | null>(null);
  const [error, setError] = useState('');
  const [dragging, setDragging] = useState(false);

  const endpoint = '/api/fileanalyse';
  const fileDescription = useMemo(() => {
    if (!file) return 'No file selected yet';
    return `${file.name} · ${formatBytes(file.size)}`;
  }, [file]);

  const selectFile = (nextFile: File | null) => {
    setFile(nextFile);
    setResult(null);
    setError('');
    setState(nextFile ? 'ready' : 'idle');
  };

  const onInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    selectFile(event.target.files?.[0] ?? null);
  };

  const onDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setDragging(false);
    selectFile(event.dataTransfer.files?.[0] ?? null);
  };

  const analyse = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!file) {
      setState('error');
      setError('Choose a file before running the analysis.');
      return;
    }

    setState('uploading');
    setError('');

    try {
      const body = new FormData();
      body.append('upfile', file);
      const response = await fetch(endpoint, { method: 'POST', body });
      const payload = await response.json();

      if (!response.ok) {
        throw new Error(payload?.error || 'The file could not be analysed.');
      }

      setResult(payload as MetadataResult);
      setState('success');
    } catch (caught) {
      setResult(null);
      setState('error');
      setError(caught instanceof Error ? caught.message : 'Unexpected upload error.');
    }
  };

  return (
    <main className="shore-app-shell">
      <header className="shore-nav">
        <a href="#top" className="shore-brand" aria-label="FileShore home">
          File<span>Shore</span>
        </a>
        <nav aria-label="Primary navigation">
          <a href="#analyser">Analyser</a>
          <a href="#response">Response</a>
          <a href="#api">API</a>
        </nav>
        <a href="#analyser" className="shore-nav-cta">Inspect a file</a>
      </header>

      <section className="shore-hero" id="top">
        <div className="shore-hero-pattern" aria-hidden="true" />
        <div className="shore-hero-copy">
          <div className="shore-status-badge">
            <span /> API ready · private by design
          </div>
          <p className="shore-kicker">File metadata microservice</p>
          <h1>
            Know every file
            <em>before it sails.</em>
            <small>Name. Type. Size. Nothing unnecessary.</small>
          </h1>
          <p className="shore-hero-description">
            Drop in a file and receive a clean metadata response instantly. The
            analyser reads the upload in memory and returns only the essentials.
          </p>
          <div className="shore-hero-meta">
            <span><strong>01</strong> Pick a file</span>
            <span><strong>02</strong> Analyse securely</span>
            <span><strong>03</strong> Copy the JSON</span>
          </div>
        </div>

        <div className="shore-upload-card" id="analyser">
          <div className="shore-card-heading">
            <div>
              <p>Live analyser</p>
              <h2>Inspect your file</h2>
            </div>
            <span className={`shore-state-dot shore-state-${state}`} aria-label={`Status: ${state}`} />
          </div>

          <form onSubmit={analyse}>
            <div
              className={`shore-drop-zone ${dragging ? 'is-dragging' : ''} ${file ? 'has-file' : ''}`}
              onDragEnter={(event) => { event.preventDefault(); setDragging(true); }}
              onDragOver={(event) => event.preventDefault()}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
              onClick={() => inputRef.current?.click()}
              role="button"
              tabIndex={0}
              onKeyDown={(event) => {
                if (event.key === 'Enter' || event.key === ' ') inputRef.current?.click();
              }}
            >
              <input
                ref={inputRef}
                id="upfile"
                name="upfile"
                type="file"
                required
                onChange={onInputChange}
              />
              <div className="shore-upload-icon"><UploadIcon /></div>
              <strong>{file ? 'File ready to inspect' : 'Drop a file here'}</strong>
              <p>{fileDescription}</p>
              <span>Browse files</span>
            </div>

            <div className="shore-file-summary" aria-live="polite">
              <div className="shore-file-symbol"><FileIcon /></div>
              <div>
                <span>Selected asset</span>
                <strong>{file?.name ?? 'Waiting for a file'}</strong>
              </div>
              <small>{file ? formatBytes(file.size) : '—'}</small>
            </div>

            <button type="submit" className="shore-analyse-button" disabled={state === 'uploading'}>
              <span>{state === 'uploading' ? 'Analysing…' : 'Analyse metadata'}</span>
              <span aria-hidden="true">→</span>
            </button>
          </form>

          {error && <p className="shore-error" role="alert">{error}</p>}
        </div>
      </section>

      <div className="shore-wave" aria-hidden="true">
        <svg viewBox="0 0 1440 90" preserveAspectRatio="none">
          <path d="M0,90 L0,31 C180,72 360,3 540,32 C720,61 900,4 1080,34 C1260,65 1360,19 1440,41 L1440,90 Z" />
        </svg>
      </div>

      <div className="shore-marquee" aria-hidden="true">
        <div>
          <span>Zero database storage</span><i>◆</i>
          <span>JSON response</span><i>◆</i>
          <span>Any file type</span><i>◆</i>
          <span>Fast in-memory analysis</span><i>◆</i>
          <span>Responsive interface</span><i>◆</i>
          <span>Zero database storage</span><i>◆</i>
          <span>JSON response</span><i>◆</i>
          <span>Any file type</span><i>◆</i>
          <span>Fast in-memory analysis</span><i>◆</i>
          <span>Responsive interface</span><i>◆</i>
        </div>
      </div>

      <section className="shore-result-section" id="response">
        <div className="shore-section-copy">
          <p>Clean output</p>
          <h2>Everything useful,<br /><em>nothing noisy.</em></h2>
          <p>
            The API returns the original filename, MIME type, and exact byte size.
            Results stay visible in the interface so they are easy to verify and copy.
          </p>
        </div>

        <div className={`shore-result-card ${result ? 'has-result' : ''}`}>
          <div className="shore-result-topline">
            <span>Response preview</span>
            <strong>{result ? '200 OK' : 'Awaiting upload'}</strong>
          </div>
          <pre>{result ? JSON.stringify(result, null, 2) : `{
  "name": "example.png",
  "type": "image/png",
  "size": 12345
}`}</pre>
          {result && (
            <button
              type="button"
              onClick={() => navigator.clipboard.writeText(JSON.stringify(result, null, 2))}
            >
              Copy response
            </button>
          )}
        </div>
      </section>

      <section className="shore-api-section" id="api">
        <div className="shore-api-card">
          <span>POST endpoint</span>
          <strong>/api/fileanalyse</strong>
          <p>Send multipart form data using the field name <code>upfile</code>.</p>
        </div>
        <div className="shore-api-card">
          <span>Response fields</span>
          <strong>name · type · size</strong>
          <p>Simple, predictable JSON for frontends, scripts, and tests.</p>
        </div>
        <div className="shore-api-card">
          <span>Upload behaviour</span>
          <strong>Processed in memory</strong>
          <p>This project does not persist uploaded files to a database.</p>
        </div>
      </section>

      <footer className="shore-footer">
        <div className="shore-brand">File<span>Shore</span></div>
        <p>Modern file metadata inspection for the web.</p>
        <a href="#top">Back to top ↑</a>
      </footer>
    </main>
  );
}
