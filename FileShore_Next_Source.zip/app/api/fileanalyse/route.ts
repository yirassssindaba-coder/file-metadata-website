import { NextResponse } from 'next/server';

function getUploadedFile(formData: FormData): File | null {
  const value = formData.get('upfile');
  return value instanceof File ? value : null;
}

async function handleUpload(request: Request) {
  try {
    const formData = await request.formData();
    const file = getUploadedFile(formData);

    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 });
    }

    return NextResponse.json({
      name: file.name,
      type: file.type,
      size: file.size,
    });
  } catch (error) {
    console.error('File upload error:', error);
    return NextResponse.json(
      { error: 'Failed to process uploaded file' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  return handleUpload(request);
}
