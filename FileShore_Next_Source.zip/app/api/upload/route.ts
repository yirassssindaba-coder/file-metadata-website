export { POST } from '../fileanalyse/route';
