# FileShore — Design Integration

The file metadata microservice now uses the supplied ShoreShack visual system while preserving the original API routes.

## Included

- sand, teal, amber, and coral design tokens
- editorial Playfair Display headings, DM Sans UI text, and DM Mono technical output
- fixed glass navigation, responsive hero, status badge, wave divider, marquee, cards, and footer
- drag-and-drop and file-picker input
- in-page API request and formatted JSON response
- copy response action, accessible keyboard drop zone, error feedback, reduced-motion support
- responsive desktop, tablet, and mobile layouts

## API compatibility

- `POST /api/fileanalyse`
- multipart field: `upfile`
- JSON fields: `name`, `type`, `size`
