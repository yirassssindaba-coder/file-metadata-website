# Validation Report

- `npm run build`: passed with Next.js 16.2.0
- `/`: statically prerendered
- `/api/fileanalyse`: dynamic route available
- `/api/upload`: dynamic alias available
- multipart upload tested with a text file; returned correct name, MIME type, and byte size
